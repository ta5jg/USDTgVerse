#!/usr/bin/env bash
# hash_file.sh
# Compute SHA256 in a cross-platform way (macOS/Linux).

set -euo pipefail
FILE="$1"

if [ ! -f "$FILE" ]; then
  echo "File not found: $FILE"
  exit 1
fi

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum "$FILE" | awk '{print $1}'
elif command -v shasum >/dev/null 2>&1; then
  shasum -a 256 "$FILE" | awk '{print $1}'
else
  echo "No sha256 tool found" >&2
  exit 2
fi
