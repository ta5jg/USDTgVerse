#!/usr/bin/env bash
# generate_official_contracts.sh
# Create official_contracts.json from template (no Python, no jq).
set -euo pipefail

TEMPLATE=${1:-"templates/official_contracts.template.json"}
OUT=${2:-"official_contracts.json"}

if [ ! -f "$TEMPLATE" ]; then
  echo "Template not found: $TEMPLATE"
  exit 1
fi

# Replace `last_updated_utc` with current UTC timestamp using sed (portable).
TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Write to OUT with timestamp updated (BSD sed compatible).
# Works on macOS and GNU: create tmp then move.
sed "s/\"last_updated_utc\": \"[^"]*\"/\"last_updated_utc\": \"$TS\"/g" "$TEMPLATE" > "$OUT"

echo "✅ Wrote $OUT"
