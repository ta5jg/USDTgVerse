#!/usr/bin/env bash
# generate_por.sh
# Create a Proof-of-Reserves JSON from template and inject numbers via env/flags.

set -euo pipefail

TEMPLATE=${1:-"templates/por.template.json"}
OUT=${2:-"por.json"}

CIRC=${CIRCULATING:-"${3:-0}"}
LOCK=${LOCKED:-"${4:-0}"}
MINT=${MINTED:-"${5:-0}"}

if [ ! -f "$TEMPLATE" ]; then
  echo "Template not found: $TEMPLATE"
  exit 1
fi

TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
TMP="$(dirname "$OUT")/.__por.tmp.$$"

# Update timestamp
sed "s/\"as_of_utc\": \"[^"]*\"/\"as_of_utc\": \"$TS\"/g" "$TEMPLATE" > "$TMP"

# Inject numbers (USDTg first asset)
sed -i.bak "s/\"circulating\": \"[^"]*\"/\"circulating\": \"$CIRC\"/g" "$TMP" || true
sed -i.bak "s/\"locked\": \"[^"]*\"/\"locked\": \"$LOCK\"/g" "$TMP" || true
sed -i.bak "s/\"minted\": \"[^"]*\"/\"minted\": \"$MINT\"/g" "$TMP" || true
rm -f "$TMP.bak"

mv "$TMP" "$OUT"
echo "✅ Wrote $OUT"
