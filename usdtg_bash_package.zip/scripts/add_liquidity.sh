#!/usr/bin/env bash
# add_liquidity.sh
# Wrapper for your native C CLI (super fast). Adjust binary/flags as needed.

set -euo pipefail

CLI=${USDTGDEX_CLI:-"./usdtgdex-cli"}   # your C binary
PAIR="${1:-USDTg/USDT}"
AMOUNT_BASE="${2:-10000}"
AMOUNT_QUOTE="${3:-10000}"

if [ ! -x "$CLI" ]; then
  echo "DEX CLI not found or not executable: $CLI"
  echo "Please set USDTGDEX_CLI or place the binary at ./usdtgdex-cli"
  exit 1
fi

# Example call – replace with your real flags
"$CLI" add-liquidity --pair "$PAIR" --base "$AMOUNT_BASE" --quote "$AMOUNT_QUOTE"

echo "✅ Added liquidity to $PAIR"
