#!/usr/bin/env bash
# publish_static.sh
# Copies JSON artifacts to your web root (macOS/Linux).

set -euo pipefail

SRC_DIR=${1:-"."}
WEB_ROOT=${2:-"/var/www/usdtgverse/public"}

mkdir -p "$WEB_ROOT"
cp -v "$SRC_DIR"/official_contracts.json "$WEB_ROOT"/ 2>/dev/null || true
cp -v "$SRC_DIR"/por.json "$WEB_ROOT"/ 2>/dev/null || true
cp -v "$SRC_DIR"/markets.tickers.json "$WEB_ROOT"/ 2>/dev/null || true

echo "✅ Published to $WEB_ROOT"
