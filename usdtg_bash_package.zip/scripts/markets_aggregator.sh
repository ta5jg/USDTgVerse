#!/usr/bin/env bash
# markets_aggregator.sh
# Pull quotes from DEX/CEX endpoints and produce a static JSON (no Python).

set -euo pipefail

OUT=${1:-"markets.tickers.json"}

# Example: replace the curl URLs with your native gateway or CEX APIs.
# Using --max-time to stay snappy; jq avoided to keep zero deps. We build minimal JSON.

TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Minimal static example until endpoints are live
cat > "$OUT" <<JSON
{{
  "as_of_utc": "{ts}",
  "tickers": [
    {{"pair":"USDTg/USDT","price":"1.0000","source":"USDTgDEX","volume_24h":"0","liquidity_usd":"0","spread_bps":0}},
    {{"pair":"USDTgV/USDTg","price":"1.0000","source":"USDTgDEX","volume_24h":"0","liquidity_usd":"0","spread_bps":0}},
    {{"pair":"USDTgG/USDTg","price":"1.0000","source":"USDTgDEX","volume_24h":"0","liquidity_usd":"0","spread_bps":0}}
  ]
}}
JSON

sed -i.bak "s/{ts}/$TS/g" "$OUT" || true
rm -f "$OUT.bak"

echo "✅ Wrote $OUT"
