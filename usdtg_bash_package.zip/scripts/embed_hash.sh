#!/usr/bin/env bash
# embed_hash.sh
# Write the computed sha256 into proof_hash field of a PoR JSON (sed-in-place).

set -euo pipefail

POR_JSON="$1"

if [ ! -f "$POR_JSON" ]; then
  echo "PoR JSON not found: $POR_JSON"
  exit 1
fi

HASH=$(./scripts/hash_file.sh "$POR_JSON")

# Replace proof_hash value
sed -i.bak "s/\"proof_hash\": \"[^\"]*\"/\"proof_hash\": \"$HASH\"/g" "$POR_JSON" || true
rm -f "$POR_JSON.bak"

echo "✅ Embedded SHA256: $HASH"
