# USDTgVerse — Zero‑Latency Bash Ops Pack (Native Chain)

Bu paket; **yalnızca bash** kullanarak (Python yok) resmi sözleşme JSON’unu,
Proof‑of‑Reserves (PoR) dosyasını, pazar verisi JSON’unu ve likidite yükleme
işlerini başlatman için şablon ve scriptler içerir.

## 1) Kurulum
```bash
unzip usdtg_bash_package.zip -d usdtg_bash
cd usdtg_bash_package
chmod +x scripts/*.sh
```

## 2) Official Contracts JSON üret
```bash
./scripts/generate_official_contracts.sh templates/official_contracts.template.json official_contracts.json
```

## 3) PoR oluştur + hash göm
```bash
# Değerleri flag veya env ile geçebilirsin
CIRCULATING=1000000 LOCKED=1000000 MINTED=1000000   ./scripts/generate_por.sh templates/por.template.json por.json

./scripts/embed_hash.sh por.json
```

## 4) DEX likidite yükleme (C CLI ile)
```bash
export USDTGDEX_CLI=./usdtgdex-cli  # C ile yazdığın hızlı binary
./scripts/add_liquidity.sh USDTg/USDT 50000 50000
```

## 5) Markets JSON üret (geçici statik)
```bash
./scripts/markets_aggregator.sh markets.tickers.json
```

## 6) Yayınla (web root’a kopyala)
```bash
sudo ./scripts/publish_static.sh . /var/www/usdtgverse/public
```

> Not: `sed -i` BSD/GNU farkları için scriptler taşınabilir yazıldı. macOS’ta ek `.bak` oluşturabilir, script siler.

## Sonraki Adımlar
- `official_contracts.json` içindeki **address=null** alanlarını, native adres formatınızla doldurun.
- `generate_por.sh` içine **C tabanlı node’u** sorgulayan hızlı bir yardımcı ekleyin (ör: `./usdtg-cli getbalance …`).
- `markets_aggregator.sh` içindeki statik blokları **USDTgDEX gateway** ve varsa CEX API çağrılarıyla değiştirin.
