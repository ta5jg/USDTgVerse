# CoinMarketCap / CoinGecko Listing Checklist (USDTgVerse)

**Last Updated (UTC):** 2025-10-04T18:58:39.020271Z

## Core Docs
- [ ] Whitepaper (latest URL)
- [ ] Tokenomics (supply breakdown, vesting, unlock schedule)
- [ ] Security Audit (PDF + SHA256 hash)
- [ ] Official Contracts JSON (multi-chain addresses)
- [ ] Team & Legal Entity (USdTG Group Technology LLC, etc.)

## Liquidity & Markets
- [ ] DEX pools live: USDTg/USDT (TRON), USDTg/USDC (ETH), USDTg/USDT (BSC)
- [ ] 7-day volume screenshot + onchain links
- [ ] Market-maker contact (if any) for CEX

## Transparency
- [ ] Proof-of-Reserves JSON endpoint (live)
- [ ] Explorer links (USDTgScan + public explorers)
- [ ] Socials: Twitter, Telegram, Medium, GitHub

## Media Kit
- [ ] Logos (SVG/PNG), icons (256/128/64), color palette
- [ ] Brand statement: ownership of “USDTg” (see branding/claim_statement.txt)
- [ ] Press one-pager (PDF)

## Submission
- [ ] CMC form (tickers, pairs, links)
- [ ] CoinGecko form (contract, pools, links)
- [ ] Follow-up emails & status tracking
