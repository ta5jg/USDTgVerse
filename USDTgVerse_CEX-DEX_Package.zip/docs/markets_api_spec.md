# USDTgVerse Markets API Spec (Draft)

**Last Updated (UTC):** 2025-10-04T18:58:39.018408Z

## Endpoints

### `GET /api/markets/tickers`
Returns consolidated tickers from CEX & DEX.

- Query: `?base=USDTg,USDTgV,USDTgG&quote=USDT,USDC,BTC,ETH`
- Response:
```json
{
  "as_of_utc":"<ts>",
  "tickers":[
    {"pair":"USDTg/USDT","price":"1.0002","source":"USDTgDEX","volume_24h":"125435.22","liquidity_usd":"210000","spread_bps":8},
    {"pair":"USDTg/USDC","price":"0.9998","source":"PancakeV2","volume_24h":"55000","liquidity_usd":"82000","spread_bps":12},
    {"pair":"USDTg/USDT","price":"1.0001","source":"CEX-Example","volume_24h":"420000","liquidity_usd":"—","orderbook_depth":"—"}
  ]
}
```

### `GET /api/markets/orderbook?pair=USDTg/USDT&source=CEX-Example`
Unified top-of-book snapshot.

### `GET /api/markets/por`
Redirects to latest Proof-of-Reserves JSON.

## Notes
- Sources: `USDTgDEX`, `PancakeV2`, `UniswapV3`, `JustMoney`, and any listed CEX (via public APIs).
- All responses include `as_of_utc` and cache headers.
