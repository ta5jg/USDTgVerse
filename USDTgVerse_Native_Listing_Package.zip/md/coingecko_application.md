# CoinGecko Listing – USDTgVerse Native Coins

**Prepared:** 2025-10-04 19:17 UTC

## Primary Coin
- Name: TetherGround USD (USDTg)  
- Symbol: USDTg  
- Type: Native Coin (not ERC20/TRC20/BEP20, no contract address)  
- Chain: USDTgVerse Chain  
- Decimals: 6  

## Additional Native Coins
- USDTgG (Governance) – Native, no contract address  
- USDTgV (Velocity) – Native, no contract address  

## Links
- Website: https://www.usdtgverse.com  
- Whitepaper: https://www.usdtg.net/whitepaper.html  
- Explorer: https://explorer.usdtg.net  
- Audit: https://www.usdtg.net/audit/USDTg_Audit_Report_Final.pdf  
- Twitter: https://twitter.com/usdtgcoin  
- Telegram: https://t.me/usdtg_token  

## Important Note
USDTg, USDTgG, and USDTgV are **native coins**, equivalent to TRX on TRON or ETH on Ethereum.  
They do not have contract addresses because they are base layer currencies of the USDTgVerse Chain.
